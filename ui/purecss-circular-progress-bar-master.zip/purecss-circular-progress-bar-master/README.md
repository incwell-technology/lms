# purecss-circular-progress-bar
Read about how this was built bottom-up and a live demo at https://jumpifzero.github.io/posts/making-a-pure-css-circular-progress-bar.html
